# Extracting Data from Text Example
This shows how you might extract data from a structured Email, PDF, or system notes.

## About
This Process contains examples of extracting data from text using calculation stages and regular expressions. This shows how you might extract data from a structured Email, PDF, or system notes. The release includes a Process containing examples, a new Utility – Strings (Extended) object containing some string processing actions. The Process also requires the standard Utility – Strings object that is distributed with the Blue Prism product to also be installed.

## Benefits
* Examples of how to find and extract data values from text documents.
* Can be used as part of a solution to extract digital data from text documents such as pdfs.
* Includes an example of how to use Regular Expressions as part of your solution.
